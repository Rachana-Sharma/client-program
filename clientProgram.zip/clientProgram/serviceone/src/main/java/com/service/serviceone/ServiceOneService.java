package com.service.serviceone;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.service.model.NumberModel;
import com.service.model.Output;

@Service
public class ServiceOneService {

	@Autowired
	private RestTemplate  restTemplate;

	public Output addEs(NumberModel firstModel, HttpEntity<NumberModel> entity) throws IOException {
	
		
		
		
		Output result = restTemplate.exchange("http://localhost:8084/add",HttpMethod.POST,entity,Output.class).getBody();
		
			return result;
		
	}
}
